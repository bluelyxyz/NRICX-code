### class: Foo
#### foo.bar(options)
- `options` <[Object]>

#### foo.foo(arg1, arg2)
- `arg1` <[string]>
- `arg2` <[string]>

#### foo.test(...files)
- `...filePaths` <[string]>

