class Foo {
}
